import socket
import os
import threading

SERVER_HOST = "0.0.0.0"
SERVER_PORT = 2121
BUFFER_SIZE = 4096
SEPARATOR = "<SEPARATOR>"

# Ensure the server_files directory exists
os.makedirs("server_files", exist_ok=True)

def handle_client(client_socket):
    try:
        command = client_socket.recv(BUFFER_SIZE).decode()
        if command.startswith("UPLOAD"):
            _, filename = command.split(SEPARATOR)
            filepath = os.path.join("server_files", filename)
            with open(filepath, "wb") as f:
                while True:
                    bytes_read = client_socket.recv(BUFFER_SIZE)
                    if not bytes_read:
                        break
                    f.write(bytes_read)
            print(f"[+] Uploaded: {filename}")

        elif command.startswith("DOWNLOAD"):
            _, filename = command.split(SEPARATOR)
            filepath = os.path.join("server_files", filename)
            if os.path.exists(filepath):
                client_socket.send("OK".encode())
                with open(filepath, "rb") as f:
                    while True:
                        bytes_read = f.read(BUFFER_SIZE)
                        if not bytes_read:
                            break
                        client_socket.sendall(bytes_read)
                print(f"[+] Sent: {filename}")
            else:
                client_socket.send("NOT_FOUND".encode())
    except Exception as e:
        print(f"[!] Error: {e}")
    finally:
        client_socket.close()

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((SERVER_HOST, SERVER_PORT))
    server_socket.listen(5)
    print(f"[*] Listening on {SERVER_HOST}:{SERVER_PORT}")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"[+] {addr} connected.")
        client_thread = threading.Thread(target=handle_client, args=(client_socket,))
        client_thread.start()

if __name__ == "__main__":
    main()









