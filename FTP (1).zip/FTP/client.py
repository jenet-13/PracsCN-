import socket
import os

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 2121
BUFFER_SIZE = 4096
SEPARATOR = "<SEPARATOR>"

def upload_file(filename):
    try:
        s = socket.socket()
        s.connect((SERVER_HOST, SERVER_PORT))
        s.send(f"UPLOAD{SEPARATOR}{filename}".encode())
        with open(filename, "rb") as f:
            while True:
                bytes_read = f.read(BUFFER_SIZE)
                if not bytes_read:
                    break
                s.sendall(bytes_read)
        print(f"[+] File uploaded: {filename}")
        s.close()
    except Exception as e:
        print(f"[!] Upload failed: {e}")

def download_file(filename):
    try:
        s = socket.socket()
        s.connect((SERVER_HOST, SERVER_PORT))
        s.send(f"DOWNLOAD{SEPARATOR}{filename}".encode())

        response = s.recv(BUFFER_SIZE).decode()
        if response == "OK":
            with open(f"downloaded_{filename}", "wb") as f:
                while True:
                    bytes_read = s.recv(BUFFER_SIZE)
                    if not bytes_read:
                        break
                    f.write(bytes_read)
            print(f"[+] File downloaded: downloaded_{filename}")
        else:
            print("[-]")
        s.close()
    except Exception as e:
        print(f"[!] Download failed: {e}")

def main():
    # Create a sample file
    sample_filename = "sample.txt"
    with open(sample_filename, "w") as f:
        f.write("This is a sample FTP transfer file.")

    print("[1] Uploading file...")
    upload_file(sample_filename)

    print("[2] Downloading file...")
    download_file(sample_filename)

if __name__ == "__main__":
    main()












